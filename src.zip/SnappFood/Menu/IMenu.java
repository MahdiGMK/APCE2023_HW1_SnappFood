package SnappFood.Menu;

public interface IMenu {
    IMenu run(String line);
}
